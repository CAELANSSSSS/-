const store_list = [
    {
        "id": 0,
        "code": "",
        "title": "打開下方選單~",
        "description": "將可以看到各個店家的介紹喔",
        "site": ""
    },
    {
        "id": 1,
        "code": "A",
        "title": "藏香經典首飾",
        "description": "藏香是一間販售西洋古董珠寶飾品店，可以收藏一些經典特色飾品。",
        "site": "https://www.facebook.com/annesbijoux/?locale=zh_TW"
    },
    {
        "id": 2,
        "code": "KDA",
        "title": "Greenray Lab 藝術空間",
        "description": "GreenRay lab 創立於2023年三月，是一間屬於綠光的實驗室，也許是一間微型藝廊\n\n是展現各種流派、風格、創作之地。我們希望透過「GreenRay lab 」\n這座進入綠光計畫的第一間玻璃屋，凝聚文化社群，使聚會交流成為常態，做文化性第三場域\n\n展覽過程我們期待進行文化轉譯，在地的元素，卻有國際的視野；最後，擷取部分創作，開發文化創意，\n將文化與生活的美好結合推廣，做更多元的商業整合。",
        "site": "https://mfcraftsman21567.gogoshopapp.com/"
    },
    {
        "id": 3,
        "code": "C",
        "title": "Sakana",
        "description": "2022年春季創立於台中的實體手作教學藝術工作室",
        "site": "https://www.facebook.com/BJDSakana/"
    },
    {
        "id": 4,
        "code": "D",
        "title": "Free Pilot",
        "description": "一群位在台中，心向大海與攝影的專業潛水教練，提供RAID系統、AIDA系統的自由潛水證照課程與SSI美人魚證照課程！\n\nPILOT擁有學到好、國內外旅遊、日常免費團練、學員IG照攝影等對內服務！",
        "site": "https://www.facebook.com/FreePilot0701/?locale=zh_TW"
    },
    {
        "id": 5,
        "code": "E",
        "title": "LEP香水實驗室",
        "description": "這裡是可以做香水DIY的地方，一次的體驗大概1個小時左右，可以調配出自己喜歡獨一無二的味道哦！",
        "site": "https://www.instagram.com/labfnp/"
    },
    {
        "id": 6,
        "code": "F",
        "title": "FANNY&FANCY",
        "description": "",
        "site": "https://www.facebook.com/FFANYNFANCY/"
    },
    {
        "id": 7,
        "code": "G",
        "title": "宇宙花間",
        "description": "宇宙花間，取自波斯菊的俗名Cosmos。當花季來臨、徜徉花海時，一花一葉瞬間幻為穿梭宇宙的浪漫想像，就像她的花語-永遠快樂那般幸福自在。?",
        "site": "https://www.facebook.com/ourcosmos.o/"
    },
    {
        "id": 8,
        "code": "H",
        "title": "山風革",
        "description": "山風革是由闖蕩法國巴黎時尚界的藝術家Angie L.所創立，獨具風格的設計，與旅居西班牙30年的藝術家PaCo全手工製作，致力於公益與工藝，用手，把愛縫在一起…",
        "site": "https://www.facebook.com/sfgleather/"
    },
    {
        "id": 9,
        "code": "I",
        "title": "森林小炭屋",
        "description": "REWOOD團隊於計劃內打造了一間森林小炭屋！五坪空間蘊藏600公斤炭！",
        "site": "https://www.facebook.com/events/549933196925952/549933206925951/?active_tab=about"
    },
    {
        "id": 10,
        "code": "J",
        "title": "老聞青",
        "description": "從二樓走下來，就可以直通老聞青Tasty Hipster，這裡除了賣咖啡也有一些簡單的餐點，像是麵食和水餃。",
        "site": "https://www.facebook.com/profile.php?id=100077568722623"
    },
    {
        "id": 11,
        "code": "K",
        "title": "小食手感",
        "description": "小食手感空間也是很可以挖寶的地方，有很多文青手作還有小飾品…等。",
        "site": "https://www.facebook.com/myminifood/?locale=zh_TW"
    },
    {
        "id": 12,
        "code": "M",
        "title": "ZOMBIE SHOP",
        "description": "Zombie Shop保有原本的童趣風格，店內販售許多美式風格的衣著、老帽及復古玩具",
        "site": "https://www.facebook.com/zombieshop2234/"
    },
    {
        "id": 13,
        "code": "N",
        "title": "製餃研所",
        "description": "這裡有提供很多種多種創意口味冰花煎餃，在Google上也有4.5顆星的好評。",
        "site": "https://www.facebook.com/dmplab/"
    },
    {
        "id": 14,
        "code": "O",
        "title": "MACACA",
        "description": "MACACA深信，運動作為工作與生活的調劑，讓身心更加平衡且力量滿盈；而服飾則是連結我們與世界的媒介，和我們一起活在當下，前往未來。",
        "site": "https://www.facebook.com/MacacaTW/"
    },
    {
        "id": 15,
        "code": "P",
        "title": "MINI AMER",
        "description": "Mini Amer.是一個生活品牌，以”融合都會及自然”為理念，希望為顧客發掘生活中的美感與歡樂，拼貼出美好生活",
        "site": "https://www.facebook.com/mini.amer.tw/"
    },
    {
        "id": 16,
        "code": "U、R、W、S",
        "title": "臺虎啜飲室",
        "description": "啜飲室是由臺虎精釀所創立的精釀啤酒體驗室。",
        "site": "https://www.facebook.com/cystaichung"
    },
    {
        "id": 17,
        "code": "V",
        "title": "心流藝",
        "description": "希望透過我們的作品，能將流體藝術的神奇傳遞給大家!",
        "site": "https://www.instagram.com/artmagician2022/?igshid=YmMyMTA2M2Y%3D"
    }
]


function showStoreList() {

    let str = '';

    for (var i = 1; i <= 17; i++) {
        str += `
        <div id="store-info-${store_list[i].id}" class="ts-box">
        <div class="ts-content ">
            <div class="ts-center">
                <div class="ts-image is-rounded ">
                    <img id="map-img" src="./img/map-min/${store_list[i].id}.PNG">
                </div>
            </div>
            <div class="ts-divider is-center-text">
                <div id="code" class="ts-text is-description">${store_list[i].code}</div>
            </div>
            <div id="title" class="ts-header ts-center is-large">
                ${store_list[i].title}
            </div>
            <div id="description" class="ts-quote is-secondary">
            ${store_list[i].description}
            </div>
            <div id="site" class="ts-content">
                <a href="${store_list[i].site}"><button class="ts-button is-fluid">店家連結</button></a>
            </div>
        </div>
    </div>
    <div class="ts-divider has-top-spaced-big"></div>
      `
    }

    document.querySelector('#store-info').innerHTML = str;
}

function showStoreListButton() {

    let str = '';

    for (var i = 1; i <= 17; i++) {
        str += `
        <a class="item" href="#store-info-${store_list[i].id}">
            <button class="ts-button is-fluid">
                <span class="ts-icon is-store-icon"></span> ${store_list[i].title}
            </button>
        </a>
      `
    }

    document.querySelector('#store-list-button').innerHTML = str;
}

